# Maseno-University-CU
This a website For The Christian Union Of Maseno University.
