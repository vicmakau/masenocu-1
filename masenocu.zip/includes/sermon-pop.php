<div class="popup" onclick="">
  <span class="popuptext" onclick="myFunctionPop()" id="myPopup">
    <span class="upcoming-sermon1">UPCOMING SERMONS</span>
    <span>Friday Fellowship</span><br>
    <span>Sermon: </span>
    <span></span><!-- sermon here -->
    <br>
    <span>by: </span>
    <span></span> <br><!-- speaker here-->
    <span>Sunday Fellowship</span><br>
    <span>Sermon: </span>
    <span></span><!-- sermon here -->
    <br>
    <span>by: </span>
    <span></span> <br><!-- speaker here-->
 
  </span>
</div>
